// English (not used - for reference only)
/*
fb.strings = {
"hintClose": "Exit (key: Esc)",
"hintPrev": "Previous (key: ←)",
"hintNext": "Next (key: →)",
"hintPlay": "Play (key: spacebar)",
"hintPause": "Pause (key: spacebar)",
"hintResize": "Resize (key: Tab)",
"imgCount": "Image %1 of %2",
"nonImgCount": "Page %1 of %2",
"mixedCount": "(%1 of %2)",
"infoText": "Info...",
"printText": "Print...",
"flashVer": "A newer version of Flash Player is required to view this content.",
"needPlayer": "%1 is required to view this content.",
"newWindow": "Open in a new window"
};
*/
fb.strings = {
hintClose: "Exit (key: Esc)",
hintPrev: "Previous (key: \u2190)",
hintNext: "Next (key: \u2192)",
hintPlay: "Play (key: spacebar)",
hintPause: "Pause (key: spacebar)",
hintResize: "Resize (key: Tab)",
imgCount: "Image %1 of %2",
nonImgCount: "Page %1 of %2",
mixedCount: "(%1 of %2)",
infoText: "Info...",
printText: "Print...",
flashVer: "A newer version of Flash Player is required to view this content.",
needPlayer: "%1 is required to view this content.",
newWindow: "Open in a new window"
};